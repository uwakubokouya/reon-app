import React, { useEffect, useState } from "react";
import GridLayout from "react-grid-layout";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";
import {
  Box, Card, Typography, Button, TextField, Chip, Divider, Stack, Checkbox,
  FormControlLabel, MenuItem, Tooltip, Dialog, DialogTitle, DialogContent, DialogActions
} from "@mui/material";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import AttachMoneyIcon from "@mui/icons-material/AttachMoney";
import ReceiptIcon from "@mui/icons-material/Receipt";
import PaidIcon from "@mui/icons-material/Paid";
import DoneAllIcon from "@mui/icons-material/DoneAll";
import { BarChart, Bar, XAxis, YAxis, Tooltip as ChartTooltip, ResponsiveContainer, Cell } from "recharts";
import { useSettings, mapStoreIdForDB } from "../SettingsContext";
import { supabase } from '../lib/supabase';

const accent = "#6366f1";
const cyan = "#06b6d4";
const pink = "#e879f9";
const gradBG = "linear-gradient(90deg, #e0e7ff 0%, #f1f5f9 80%)";
const glassStyle = {
  background: "rgba(255,255,255,0.89)",
  boxShadow: "0 8px 32px 0 rgba(34,197,246,0.13), 0 1.5px 8px 0 #6366f113",
  border: "1.5px solid rgba(220,230,255,0.18)",
  backdropFilter: "blur(7px)",
  borderRadius: 12,
  overflow: "hidden"
};
const defaultLayout = [
  { i: "main", x: 0, y: 0, w: 12, h: 30, minW: 8, minH: 18 },
];
function saveLayoutToStorage(layout) {
  localStorage.setItem("reon-fuzoku-daily-layout", JSON.stringify(layout));
}
function getLayoutFromStorage() {
  try {
    return JSON.parse(localStorage.getItem("reon-fuzoku-daily-layout")) || defaultLayout;
  } catch {
    return defaultLayout;
  }
}

export default function DailyReportPage() {
  const { staff = [], menuList = [], discounts = [], coupons = [], expenseItems = [], currentStoreId, sessionId, extraCookies } = useSettings();
  const store_id = mapStoreIdForDB ? mapStoreIdForDB(currentStoreId) : currentStoreId;
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));

  // 集計データ
  const [autoReport, setAutoReport] = useState({
    totalSales: 0,
    salesByType: { cash: 0, card: 0, paypay: 0 },
    courses: [],
    shimei: [],
    shimeiCount: [],
    ops: [],
    opCount: [],
    discounts: [],
    castPays: [],
    totalCastPay: 0,
    couponUsage: [],
    orderList: [],
  });

  const expenseOptions = (expenseItems || []).map(x => typeof x === "object" ? x.name : x);
  const nonCastStaff = (staff || []).filter(s =>
    s.isActive !== false &&
    s.role && s.role !== "キャスト"
  );

  const [expenses, setExpenses] = useState([{ type: "支出", category: "", detail: "", amount: "" }]);
  const [pay, setPay] = useState([{ staff: "", amount: "" }]);
  const [checklist, setChecklist] = useState([
    { label: "出勤キャスト点呼・身だしなみ確認", checked: false },
    { label: "ルーム/待合室 清掃・消毒", checked: false },
    { label: "釣銭・現金残高点検", checked: false },
    { label: "予約/受付リスト確認", checked: false },
    { label: "備品/消耗品チェック", checked: false }
  ]);
  const [memo, setMemo] = useState("");
  const [closed, setClosed] = useState(false);
  const [layout, setLayout] = useState(getLayoutFromStorage());
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");
  const [diaries, setDiaries] = useState([]);

  const [confirmNoDiaryOpen, setConfirmNoDiaryOpen] = useState(false);
  

  const recruitResults = [
   "採用",
    "面接のみ",
    "返事待ち",
    "不採用",
    "その他"
  ];

  const [recruits, setRecruits] = useState([
    { media: "", name: "", result: "", memo: "" }
  ]);

  // --- 1. 写メ日記取得 ---
  const handleFetchDiaries = async () => {
    setSaving(true);
    try {
      // 期間を計算
      const center = new Date(date);
      const fromDate = new Date(center); fromDate.setDate(center.getDate() - 1);
      const toDate = new Date(center); toDate.setDate(center.getDate() + 0);
  
      const yyyyMMdd = d => d.toISOString().slice(0, 10);
      const API_BASE = "http://localhost:8000";
      const url = `${API_BASE}/api/heaven/diary_hourly`;
      const body = {
        session_id: sessionId,
        shopdir: store_id,
        extra_cookies: extraCookies,
        from_date: yyyyMMdd(fromDate),
        to_date: yyyyMMdd(toDate),
      };
      const res = await fetch(url, { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
  
      // ここで406判定
      if (res.status === 406) {
        setDiaries([]);
        alert("写メ日記はありませんでした");
        return; // ここでreturnでもOK
      }
  
      const data = await res.json();
      if (data.ok && data.diaries) {
        // --- 既存日記（diaries）との重複判定 ---
        const newDiaries = data.diaries;
        const existingKeys = new Set(
          diaries.map(d => `${d.date}_${d.cast}_${d.title}`)
        );
        const uniqueNewDiaries = newDiaries.filter(
          d => !existingKeys.has(`${d.date}_${d.cast}_${d.title}`)
        );
        const merged = [...diaries, ...uniqueNewDiaries];
  
        setDiaries(merged);
        alert(`写メ日記データを取得しました！（新規${uniqueNewDiaries.length}件）`);
      } else {
        setDiaries([]);
        alert("写メ日記の取得に失敗しました");
      }
    } catch (e) {
      setDiaries([]);
      alert("エラー: " + e.message);
    } finally {
      setSaving(false);
    }
  };

    useEffect(() => { 
      async function fetchData() {
        if (!store_id || !date) return;

        // 1. まず締めレコード取得
        const { data: report } = await supabase
          .from('daily_reports')
          .select('*')
          .eq('store_id', store_id)
          .eq('report_date', date)
          .maybeSingle();
    
        if (report) {
          setClosed(!!report.closed);
          setMemo(report.memo || "");
          setChecklist(report.checklist || [
            { label: "出勤キャスト点呼・身だしなみ確認", checked: false },
            { label: "ルーム/待合室 清掃・消毒", checked: false },
            { label: "釣銭・現金残高点検", checked: false },
            { label: "予約/受付リスト確認", checked: false },
            { label: "備品/消耗品チェック", checked: false }
          ]);
          setExpenses(report.expenses || [{ category: "", detail: "", amount: "" }]);
          setPay(report.pay || [{ staff: "", amount: "" }]);
          setDiaries(report.diary_logs || []); 
          setRecruits(report.recruit_logs || [{ media: "", name: "", result: "", memo: "" }]); 
        } else {
          setClosed(false);
          setMemo("");
          setChecklist([
            { label: "出勤キャスト点呼・身だしなみ確認", checked: false },
            { label: "ルーム/待合室 清掃・消毒", checked: false },
            { label: "釣銭・現金残高点検", checked: false },
            { label: "予約/受付リスト確認", checked: false },
            { label: "備品/消耗品チェック", checked: false }
          ]);
          setExpenses([{ category: "", detail: "", amount: "" }]);
          setPay([{ staff: "", amount: "" }]);
          setDiaries([]);
          setRecruits([{ media: "", name: "", result: "", memo: "" }]);
        }
    
        // --- 集計 ---
        const { data: reservations } = await supabase
          .from('reservations')
          .select('*')
          .eq('store_id', store_id)
          .gte('datetime', `${date}T00:00:00`)
          .lte('datetime', `${date}T23:59:59`)
          .not('kubun', 'ilike', '%キャンセル%');
    
        // --- 既存の集計ロジック ---
        const salesByType = { cash: 0, card: 0, paypay: 0 };
        let totalSales = 0, courses = {}, shimei = {}, shimeiCount = {}, ops = {}, opCount = {}, discountTotals = {}, castPaysRaw = {}, totalCastPayRaw = 0;
        let couponUsage = {}, orderList = {};
    
        for (const r of reservations || []) {
          // 支払い
          if (r.payment_method === "cash") salesByType.cash += Number(r.price) || 0;
          if (r.payment_method === "card") salesByType.card += Number(r.price) || 0;
          if (r.payment_method === "paypay") salesByType.paypay += Number(r.price) || 0;
          totalSales += Number(r.price) || 0;
    
          // コース
          if (r.course) courses[r.course] = (courses[r.course] || 0) + (Number(r.course_price) || 0);
    
          // 指名金額・本数
          if (r.shimei) {
            shimei[r.shimei] = (shimei[r.shimei] || 0) + (Number(r.shimei_fee) || 0);
            shimeiCount[r.shimei] = (shimeiCount[r.shimei] || 0) + 1;
          }
    
          // --- OP金額・本数 集計 ---
          if (Array.isArray(r.op_detail) && r.op_detail.length > 0) {
            for (const opItem of r.op_detail) {
              ops[opItem.name] = (ops[opItem.name] || 0) + Number(opItem.price || 0);
              opCount[opItem.name] = (opCount[opItem.name] || 0) + 1;
            }
          } else if (Array.isArray(r.op) && r.op.length > 0) {
            for (const opName of r.op) {
              ops[opName] = (ops[opName] || 0) + ((Number(r.op_price) || 0) / r.op.length);
              opCount[opName] = (opCount[opName] || 0) + 1;
            }
          }
    
          // --- 割引金額 ---
          if (r.discount && r.discount !== "null" && r.discount !== "") {
            discountTotals[r.discount] = (discountTotals[r.discount] || 0) + (Number(r.discount_amount) || 0);
          }
    
          // キャスト給（予約ベースの集計値＝従来方式）
          if (r.cast_id) {
            castPaysRaw[r.cast_id] = (castPaysRaw[r.cast_id] || 0) + (Number(r.cast_pay) || 0);
            totalCastPayRaw += Number(r.cast_pay) || 0;
          }
        }
    
        // ===【ここから給料確定データ反映】===
        // 1. salariesから確定済み金額を取得
        const { data: salaryRows } = await supabase
          .from('salaries')
          .select('*')
          .eq('store_id', store_id)
          .eq('date', date);
    
        // 2. 確定済み（final_salary）マップを作成
        const salaryMap = {};
        for (const s of salaryRows || []) {
          if (s.cast_id && s.final_salary != null) {
            salaryMap[s.cast_id] = Number(s.final_salary);
          }
        }
    
        // --- castPaysをsalariesベースにする（変更！）
        let castPays = [];
        let totalCastPay = 0;
        for (const castId of Object.keys(salaryMap)) { // salaryMapのkeyだけに限定
          let total = salaryMap[castId];
          castPays.push({ cast_id: castId, total });
          totalCastPay += total;
        }
    
        // --- 集計データセット ---
        setAutoReport({
          totalSales,
          salesByType,
          courses: Object.entries(courses).map(([name, total]) => ({ name, total })),
          shimei: Object.entries(shimei).map(([name, total]) => ({ name, total })),
          shimeiCount: Object.entries(shimeiCount).map(([name, count]) => ({ name, count })),
          ops: Object.entries(ops).map(([name, total]) => ({ name, total })),
          opCount: Object.entries(opCount).map(([name, count]) => ({ name, count })),
          discounts: Object.entries(discountTotals).map(([name, amount]) => ({ name, amount })),
          castPays,           // ←グラフやUIで使うのはこのsalaries優先の配列
          totalCastPay,       // ←合計もsalaries優先
          couponUsage,
          orderList,
          // --- 必要なら下記で予約ベースの合計値も保存できます ---
          castPaysRaw,        // ←予約ベースのキャスト給（未確定用 or 比較用）
          totalCastPayRaw,    // ←予約ベースの総キャスト給
        });
      }
      fetchData();
    }, [store_id, date]);

  // 日付移動
  const moveDay = diff => {
    const dt = new Date(date);
    dt.setDate(dt.getDate() + diff);
    setDate(dt.toISOString().slice(0, 10));
  };

  // 入力系
  const handleExpenseChange = (i, field, val) => {
    const arr = [...expenses];
    arr[i][field] = val;
    setExpenses(arr);
  };
  const handleAddExpense = () => setExpenses([...expenses, { category: "", detail: "", amount: "" }]);
  const handlePayChange = (i, field, val) => {
    const arr = [...pay];
    arr[i][field] = val;
    setPay(arr);
  };
  const handleAddPay = () => setPay([...pay, { staff: "", amount: "" }]);
  const handleChecklistChange = idx =>
    setChecklist(checklist.map((c, i) => i === idx ? { ...c, checked: !c.checked } : c));

  // 合計
  const totalExpense = expenses.reduce((sum, e) => {
    const v = Number(e.amount || 0);
    return sum + (e.type === "収入" ? v : -v);
  }, 0);
  const totalPay = pay.reduce((sum, p) => sum + Number(p.amount || 0), 0);
  const totalDiscount = autoReport.discounts.reduce((a, b) => a + b.amount, 0);
  const totalCastPay = autoReport.totalCastPay || 0; // 総キャスト給（集計済み）
  const cashBalance =
    Number(autoReport.totalSales || 0)   // 売上総額（現金＋カード＋PayPay含む総額）
    - Number(totalCastPay)
    - Number(totalExpense)
    - Number(totalPay);

  // 直近3日分を取得
  const getRecentDiaryLogs = async (store_id, date) => {
    const dates = [];
    for (let i = -2; i <= 0; i++) {
      const d = new Date(date);
      d.setDate(d.getDate() + i);
      dates.push(d.toISOString().slice(0, 10));
    }
    const { data, error } = await supabase
      .from("daily_reports")
      .select("diary_logs")
      .eq("store_id", store_id)
      .in("report_date", dates);

    // diary_logsが配列で返る（多重配列になる可能性あり）
    if (!data) return [];
    // フラット化
    return data.flatMap(r => r.diary_logs || []);
  };

   // これを追加！！
  const handleCloseButtonClick = () => {
    if (!diaries || diaries.length === 0) {
      setConfirmNoDiaryOpen(true);
      return;
    }
    handleClose();
  };
  
  // 締め保存
  const handleClose = async () => {
    setSaving(true);
    setErr("");
    try {
      // ----------【追加】直近3日分の既存日記を取得 ----------
      const recentDiaries = await getRecentDiaryLogs(store_id, date);
      // 重複判定キーセット（date+cast+title, 必要ならdiary_urlも加えてOK）
      const existingKeys = new Set(
        recentDiaries.map(d => `${d.date}_${d.cast}_${d.title}`)
      );
      // 今回のdiariesで新規のみ抽出
      const uniqueNewDiaries = diaries.filter(
        d => !existingKeys.has(`${d.date}_${d.cast}_${d.title}`)
      );
  
      // ---------- 通常の保存処理 ----------
      const saveData = {
        store_id: store_id,
        report_date: date,
        sales_cash: autoReport.salesByType.cash,
        sales_card: autoReport.salesByType.card,
        sales_paypay: autoReport.salesByType.paypay,
        discount_total: autoReport.discounts.reduce((sum, d) => sum + (Number(d.amount) || 0), 0),
        expense_total: totalExpense,
        pay_total: totalPay,
        cash_balance: cashBalance,
        memo: memo,
        closed: true,
        order_list: autoReport.courses,
        coupon_usage: autoReport.discounts,
        expenses: expenses,
        pay: pay,
        checklist: checklist,
        cast_salary: autoReport.castPays,
        op_detail: autoReport.ops,
        op_count: autoReport.opCount,
        shimei: autoReport.shimei,
        shimei_count: autoReport.shimeiCount,
        // ★「新規のみ」のdiary_logsを保存
        diary_logs: uniqueNewDiaries,
        recruit_logs: recruits,
      };
      console.log("[保存送信データ]", saveData);
  
      const { error } = await supabase.from("daily_reports")
        .upsert([saveData], { onConflict: ['report_date', 'store_id'] });
  
      if (error) throw error;
      setClosed(true);
    } catch (e) {
      setErr(e.message || "保存に失敗しました");
    } finally {
      setSaving(false);
    }
  };
  const handleUnlock = () => setClosed(false);

  // グラフ用
  const courseChart = autoReport.courses.length
    ? autoReport.courses.map(x => ({ name: x.name, 金額: x.total }))
    : [];
  const shimeiChart = autoReport.shimei.some(x => x.total > 0)
    ? autoReport.shimei.map(x => ({ name: x.name, 金額: x.total }))
    : autoReport.shimeiCount.map(x => ({ name: x.name, 件数: x.count }));
  const opChart = autoReport.ops.some(x => x.total > 0)
    ? autoReport.ops.map(x => ({ name: x.name, 金額: x.total }))
    : autoReport.opCount.map(x => ({ name: x.name, 件数: x.count }));
  const castPayChart = autoReport.castPays.map(c => ({
    name: (staff || []).find(s => String(s.id) === String(c.cast_id))?.name || `ID:${c.cast_id}`,
    給料: c.total
  }));

  return (
    <Box sx={{
      width: "100%",
      minHeight: "100vh",
      bgcolor: gradBG,
      px: { xs: 1, md: 3 },
      pt: 3,
      pb: 4,
      overflowX: "auto"
    }}>
      {/* ---- ヘッダー ---- */}
      <Box mb={2} display="flex" alignItems="center" gap={2}>
        <Card sx={{
          width: 54, height: 54, ...glassStyle, borderRadius: "50%",
          display: "flex", alignItems: "center", justifyContent: "center"
        }}>
          <CalendarMonthIcon sx={{ fontSize: 32, color: accent }} />
        </Card>
        <Box>
          <Typography variant="h4" fontWeight={900} letterSpacing={1.5}
            sx={{ color: accent, textShadow: "0 2px 14px #818cf866" }}>
            風俗店 日報・締め作業
          </Typography>
        </Box>
        <Box ml="auto" display="flex" alignItems="center" gap={1}>
          <Button onClick={() => moveDay(-1)}>前日</Button>
          <TextField
            type="date"
            size="small"
            variant="outlined"
            value={date}
            onChange={e => setDate(e.target.value)}
            sx={{ minWidth: 140, bgcolor: "#fff", borderRadius: 2 }}
            inputProps={{ style: { fontSize: 18 } }}
          />
          <Button onClick={() => moveDay(1)}>翌日</Button>
        </Box>
      </Box>
      {/* ---- エラー ---- */}
      <Dialog open={!!err} onClose={() => setErr("")}>
        <DialogTitle>保存エラー</DialogTitle>
        <DialogContent>{err}</DialogContent>
        <DialogActions>
          <Button onClick={() => setErr("")}>閉じる</Button>
        </DialogActions>
      </Dialog>
      {/* ---- レイアウト ---- */}
      <GridLayout
        className="layout"
        layout={layout}
        cols={16}
        rowHeight={38}
        width={1400}
        isDraggable
        isResizable
        draggableHandle=".move-handle"
        onLayoutChange={l => {
          setLayout(l);
          saveLayoutToStorage(l);
        }}
        style={{ minHeight: 650, margin: "0 auto" }}
      >
        {/* ---- 日報パネル ---- */}
        <div key="main" style={{ display: "flex", height: "100%" }}>
          <Box sx={{
            width: "100%",
            ...glassStyle,
            borderRadius: 12,
            p: { xs: 2, md: 4 },
            minWidth: 400,
            height: "100%",
            display: "flex",
            flexDirection: "column"
          }}>
            <Box className="move-handle" sx={{ cursor: "move", mb: 1, pb: 1, borderBottom: "1.5px dashed #e0e7ef" }}>
              <Typography fontWeight={700} color={cyan} fontSize={16}>日報入力パネル（ドラッグ可）</Typography>
            </Box>
            <Box display="flex" alignItems="center" mb={2} gap={2}>
              <CalendarMonthIcon sx={{ color: cyan }} />
              <Typography fontWeight={700} fontSize={17}>
                {date}
              </Typography>
              {closed && (
                <Chip label="締め済" color="success" icon={<DoneAllIcon />} sx={{ ml: 2, fontWeight: "bold" }} onClick={() => {}} />
              )}
            </Box>
            <Divider sx={{ my: 2 }} />

            {/* ====== 売上・詳細 ====== */}
            <Box mb={3}>
              <Typography fontWeight={700} fontSize={17} color={accent} mb={0.5}>
                <AttachMoneyIcon sx={{ mr: 1, color: cyan }} />本日売上
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap" sx={{ mb: 2 }}>
                <Chip label={`現金：${autoReport.salesByType.cash.toLocaleString()}円`} color="primary" sx={{ fontWeight: "bold", bgcolor: "#e0f7fa" }} onClick={() => {}} />
                <Chip label={`カード：${autoReport.salesByType.card.toLocaleString()}円`} sx={{ fontWeight: "bold", bgcolor: "#f3e8ff", color: "#6366f1" }} onClick={() => {}} />
                <Chip label={`PayPay：${autoReport.salesByType.paypay.toLocaleString()}円`} sx={{ fontWeight: "bold", bgcolor: "#e0f7fa", color: "#06b6d4" }} onClick={() => {}} />
                <Chip label={`売上合計：${autoReport.totalSales.toLocaleString()}円`} color="secondary" sx={{ fontWeight: "bold", bgcolor: "#dbeafe", fontSize: 22, px: 3 }} onClick={() => {}} />
              </Stack>
              {/* グラフ付き集計 */}
              <Box sx={{ display: "flex", flexWrap: "wrap", gap: 3 }}>
                <Card sx={{ p: 2, minWidth: 230, borderRadius: 6, boxShadow: "0 4px 18px #818cf11a" }}>
                  <Typography fontWeight={700} mb={1}>コース売上（グラフ）</Typography>
                  <ResponsiveContainer width="100%" height={90}>
                    <BarChart data={courseChart} layout="vertical" margin={{ left: 20, right: 10 }}>
                      <XAxis type="number" hide />
                      <YAxis dataKey="name" type="category" width={55} />
                      <Bar dataKey="金額" fill={cyan} />
                      <ChartTooltip formatter={v => `${v.toLocaleString()}円`} />
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
                <Card sx={{ p: 2, minWidth: 230, borderRadius: 6, boxShadow: "0 4px 18px #818cf11a" }}>
                  <Typography fontWeight={700} mb={1}>指名売上（グラフ）</Typography>
                  {shimeiChart.length ? (
                    <ResponsiveContainer width="100%" height={90}>
                      <BarChart data={shimeiChart} layout="vertical" margin={{ left: 20, right: 10 }}>
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" width={70} />
                        <Bar dataKey={shimeiChart[0].金額 != null ? "金額" : "件数"} fill={accent} />
                        <ChartTooltip formatter={v => shimeiChart[0].金額 != null ? `${v.toLocaleString()}円` : `${v}件`} />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : <Typography color="#999">データなし</Typography>}
                </Card>
                <Card sx={{ p: 2, minWidth: 230, borderRadius: 6, boxShadow: "0 4px 18px #818cf11a" }}>
                  <Typography fontWeight={700} mb={1}>OP売上（グラフ）</Typography>
                  {opChart.length ? (
                    <ResponsiveContainer width="100%" height={90}>
                      <BarChart data={opChart} layout="vertical" margin={{ left: 20, right: 10 }}>
                        <XAxis type="number" hide />
                        <YAxis dataKey="name" type="category" width={70} />
                        <Bar dataKey={opChart[0].金額 != null ? "金額" : "件数"} fill={pink} />
                        <ChartTooltip formatter={v => opChart[0].金額 != null ? `${v.toLocaleString()}円` : `${v}件`} />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : <Typography color="#999">データなし</Typography>}
                </Card>
                <Card sx={{ p: 2, minWidth: 150, borderRadius: 6, boxShadow: "0 4px 18px #818cf11a" }}>
                  <Typography fontWeight={700} mb={1}>割引</Typography>
                  {autoReport.discounts.length ? (
                    autoReport.discounts.map((d, i) =>
                      <Typography key={i} fontSize={14}>{d.name}：{d.amount.toLocaleString()}円</Typography>
                    )
                  ) : (
                    <Typography color="#999">データなし</Typography>
                  )}
                </Card>
              </Box>
            </Box>

            {/* ==== キャスト給明細 ==== */}
            <Divider sx={{ my: 2 }} />
            <Box mb={3}>
              <Typography fontWeight={900} fontSize={20} color={cyan} mb={1}>
                <PaidIcon sx={{ color: pink, mr: 1, fontSize: 23, mb: "-3px" }} />
                総キャスト給：{autoReport.totalCastPay.toLocaleString()}円
              </Typography>
              <ResponsiveContainer width="100%" height={80}>
                <BarChart data={castPayChart} layout="vertical" margin={{ left: 25, right: 5 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" width={45} />
                  <Bar dataKey="給料">
                    {castPayChart.map((c, i) => (
                      <Cell key={i} fill={i % 2 ? pink : cyan} />
                    ))}
                  </Bar>
                  <ChartTooltip formatter={v => `${v.toLocaleString()}円`} />
                </BarChart>
              </ResponsiveContainer>
            </Box>

            <Divider sx={{ my: 2 }} />
            {/* ---- 経費入力 ---- */}
            <Box mb={3}>
              <Typography fontWeight={700} fontSize={17} color={accent} mb={1}>
                <ReceiptIcon sx={{ mr: 1, color: "#38bdf8" }} />経費入力
              </Typography>
              <Stack spacing={1.2}>
                {expenses.map((exp, i) => (
                  <Stack key={i} direction="row" spacing={2} alignItems="center">
                    <TextField
                      select
                      label="カテゴリ"
                      value={exp.category}
                      onChange={e => handleExpenseChange(i, "category", e.target.value)}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      sx={{ minWidth: 140, width: 180, bgcolor: "#f9fafb", borderRadius: 2 }}
                    >
                      <MenuItem value="">選択</MenuItem>
                      {expenseOptions.map(x =>
                        <MenuItem key={x} value={x}>{x}</MenuItem>
                      )}
                    </TextField>
                    <TextField
                      label="詳細"
                      value={exp.detail}
                      onChange={e => handleExpenseChange(i, "detail", e.target.value)}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      sx={{ minWidth: 140, width: 220, bgcolor: "#f9fafb", borderRadius: 2 }}
                    />
                    <TextField
                      label="金額"
                      type="number"
                      value={exp.amount}
                      onChange={e => handleExpenseChange(i, "amount", e.target.value)}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      InputProps={{ endAdornment: <span>円</span> }}
                      sx={{ width: 120, bgcolor: "#f9fafb", borderRadius: 2 }}
                    />
                    <TextField
                      select
                      label="区分"
                      value={exp.type || "支出"}
                      onChange={e => handleExpenseChange(i, "type", e.target.value)}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      sx={{ minWidth: 80, bgcolor: "#f9fafb", borderRadius: 2, mr: 1 }}
                    >
                      <MenuItem value="支出">支出</MenuItem>
                      <MenuItem value="収入">収入</MenuItem>
                    </TextField>
                    {/* ★「登録」ボタン */}
                    {i === expenses.length - 1 && !closed && (
                      <>
                        <Button
                          size="small"
                          variant="contained"
                          color="primary"
                          sx={{ fontWeight: 700, borderRadius: 2, mr: 1 }}
                          onClick={() => {
                            // ここに保存処理を追加
                            const amount = exp.type === "収入"
                              ? Math.abs(Number(exp.amount) || 0)
                              : -Math.abs(Number(exp.amount) || 0);
                            alert(`経費登録: ${exp.category} ${exp.detail} ${amount}円`);
                            // supabaseへの保存例
                            // await supabase.from("expenses").upsert([{ ...exp, amount, date, store_id }]);
                          }}
                          disabled={!exp.category || !exp.amount}
                        >
                          登録
                        </Button>
                        <Tooltip title="経費行を追加">
                          <Button
                            size="small"
                            sx={{ bgcolor: cyan, color: "#fff", borderRadius: 2, px: 2, fontWeight: 700 }}
                            onClick={handleAddExpense}
                            disabled={expenses.length > 7}
                          >＋</Button>
                        </Tooltip>
                      </>
                    )}
                  </Stack>
                ))}
              </Stack>
              <Box mt={1} ml={1.5}>
                <Chip
                  label={`合計：${totalExpense >= 0 ? '+' : ''}${totalExpense.toLocaleString()}円`}
                  color={totalExpense >= 0 ? "success" : "info"}
                  sx={{ fontWeight: "bold", bgcolor: "#e0f2fe" }}
                  onClick={() => {}}
                />
              </Box>
            </Box>
            
            {/* ---- スタッフ日払い ---- */}
            <Divider sx={{ my: 2 }} />
            <Box mb={3}>
              <Typography fontWeight={700} fontSize={17} color={accent} mb={1}>
                <PaidIcon sx={{ mr: 1, color: "#f472b6" }} />スタッフ日払い
              </Typography>
              <Stack spacing={1.2}>
                {pay.map((p, i) => (
                  <Stack key={i} direction="row" spacing={2} alignItems="center">
                    <TextField
                      select
                      label="スタッフ名"
                      value={p.staff}
                      onChange={e => handlePayChange(i, "staff", e.target.value)}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      sx={{ minWidth: 180, width: 240, bgcolor: "#f9fafb", borderRadius: 2 }}
                    >
                      <MenuItem value="">選択</MenuItem>
                      {(nonCastStaff || []).map(x =>
                        <MenuItem key={x.name || x} value={x.name || x}>{x.name || x}</MenuItem>
                      )}
                    </TextField>
                    <TextField
                      label="金額"
                      type="number"
                      value={p.amount}
                      onChange={e => handlePayChange(i, "amount", e.target.value)}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      InputProps={{ endAdornment: <span>円</span> }}
                      sx={{ width: 180, bgcolor: "#f9fafb", borderRadius: 2 }}
                    />
                    {/* ★「登録」ボタン */}
                    {i === pay.length - 1 && !closed && (
                      <>
                        <Button
                          size="small"
                          variant="contained"
                          color="primary"
                          sx={{ fontWeight: 700, borderRadius: 2, mr: 1 }}
                          onClick={() => {
                            alert(`日払い登録: ${p.staff} ${p.amount}円`);
                            // supabaseへの保存例
                            // await supabase.from("staff_pays").upsert([{ ...p, date, store_id }]);
                          }}
                          disabled={!p.staff || !p.amount}
                        >
                          登録
                        </Button>
                        <Tooltip title="日払い行を追加">
                          <Button
                            size="small"
                            sx={{ bgcolor: "#f472b6", color: "#fff", borderRadius: 2, px: 2, fontWeight: 700 }}
                            onClick={handleAddPay}
                            disabled={pay.length > 7}
                          >＋</Button>
                        </Tooltip>
                      </>
                    )}
                  </Stack>
                ))}
              </Stack>
              <Box mt={1} ml={1.5}>
                <Chip
                  label={`合計：${totalPay.toLocaleString()}円`}
                  color="secondary"
                  sx={{ fontWeight: "bold", bgcolor: "#fbeffb" }}
                  onClick={() => {}}
                />
              </Box>
            </Box>
            
            {/* ---- 求人情報 ---- */}
            <Divider sx={{ my: 2 }} />
            <Box mb={3}>
              <Typography fontWeight={700} fontSize={17} color={accent} mb={0.5}>
                求人情報
              </Typography>
              <Stack spacing={1.2}>
                {recruits.map((rec, i) => (
                  <Stack key={i} direction="row" spacing={2} alignItems="center">
                    <TextField
                      label="媒体名"
                      value={rec.media}
                      onChange={e => {
                        const arr = [...recruits];
                        arr[i].media = e.target.value;
                        setRecruits(arr);
                      }}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      sx={{ minWidth: 100, width: 120, bgcolor: "#f9fafb", borderRadius: 2 }}
                    />
                    <TextField
                      label="名前"
                      value={rec.name}
                      onChange={e => {
                        const arr = [...recruits];
                        arr[i].name = e.target.value;
                        setRecruits(arr);
                      }}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      sx={{ minWidth: 100, width: 120, bgcolor: "#f9fafb", borderRadius: 2 }}
                    />
                    <TextField
                      select
                      label="結果"
                      value={rec.result}
                      onChange={e => {
                        const arr = [...recruits];
                        arr[i].result = e.target.value;
                        setRecruits(arr);
                      }}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      sx={{ minWidth: 120, width: 130, bgcolor: "#f9fafb", borderRadius: 2 }}
                    >
                      {recruitResults.map(option => (
                        <MenuItem key={option} value={option}>{option}</MenuItem>
                      ))}
                    </TextField>
                    <TextField
                      label="備考"
                      value={rec.memo}
                      onChange={e => {
                        const arr = [...recruits];
                        arr[i].memo = e.target.value;
                        setRecruits(arr);
                      }}
                      size="small"
                      variant="outlined"
                      disabled={closed}
                      sx={{ minWidth: 160, width: 200, bgcolor: "#f9fafb", borderRadius: 2 }}
                    />
                    {/* ★「登録」ボタン */}
                    {i === recruits.length - 1 && !closed && (
                      <>
                        <Button
                          size="small"
                          variant="contained"
                          color="primary"
                          sx={{ fontWeight: 700, borderRadius: 2, mr: 1 }}
                          onClick={() => {
                            alert(`求人情報登録: ${rec.media} ${rec.name}`);
                            // supabaseへの保存例
                            // await supabase.from("recruits").upsert([{ ...rec, date, store_id }]);
                          }}
                          disabled={!rec.media || !rec.name}
                        >
                          登録
                        </Button>
                        <Tooltip title="求人情報行を追加">
                          <Button
                            size="small"
                            sx={{ bgcolor: cyan, color: "#fff", borderRadius: 2, px: 2, fontWeight: 700 }}
                            onClick={() => setRecruits([...recruits, { media: "", name: "", result: "", memo: "" }])}
                            disabled={recruits.length > 10}
                          >＋</Button>
                        </Tooltip>
                      </>
                    )}
                  </Stack>
                ))}
              </Stack>
            </Box>

            {/* ---- チェックリスト ---- */}
            <Divider sx={{ my: 2 }} />
            <Box mb={3}>
              <Typography fontWeight={700} fontSize={17} color={accent} mb={0.5}>
                <DoneAllIcon sx={{ mr: 1, color: "#38bdf8" }} />本日営業チェックリスト
              </Typography>
              <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap alignItems="center">
                {checklist.map((item, i) => (
                  <FormControlLabel
                    key={item.label}
                    control={
                      <Checkbox
                        checked={item.checked}
                        onChange={() => handleChecklistChange(i)}
                        disabled={closed}
                        sx={{
                          color: cyan,
                          "&.Mui-checked": { color: accent }
                        }}
                      />
                    }
                    label={<Typography fontSize={14} fontWeight={600}>{item.label}</Typography>}
                  />
                ))}
                {/* チェックリストの右端にボタンを追加 */}
                <Button
                  variant="contained"
                  color="info"
                  sx={{ fontWeight: 700, borderRadius: 2, ml: 2, minWidth: 140 }}
                  onClick={handleFetchDiaries}
                  disabled={saving}
                >
                  写メ日記取得・保存
                </Button>
              </Stack>
            </Box>

            {/* ---- 現金残高 ---- */}
            <Divider sx={{ my: 2 }} />
            <Box
              mb={3}
              sx={{
                background: "linear-gradient(90deg,#a5b4fc 0%, #5eead4 100%)",
                borderRadius: 3,
                boxShadow: "0 4px 24px #5eead477,0 1.5px 8px #6366f116",
                p: 3,
                display: "flex",
                alignItems: "center",
                gap: 2,
                position: "relative",
                minHeight: 80
              }}
            >
              <AttachMoneyIcon sx={{ fontSize: 40, color: "#fff", mr: 2, textShadow: "0 2px 12px #6366f155" }} />
              <Box>
                <Typography
                  fontWeight={900}
                  fontSize={22}
                  color="#fff"
                  letterSpacing={1.5}
                  sx={{
                    textShadow: "0 2px 12px #6366f180"
                  }}
                >
                  本日現金残高
                </Typography>
                <Typography
                  sx={{
                    fontSize: 13,
                    color: "#f1f5f9",
                    mt: 0.2,
                    textShadow: "0 2px 12px #2221"
                  }}
                >
                  売上−給料-経費−日払い の自動計算
                </Typography>
              </Box>
              <Box sx={{ flex: 1 }} />
              <Box
                sx={{
                  px: 3,
                  py: 1.5,
                  bgcolor: "#fff",
                  color: "#22d3ee",
                  fontWeight: 900,
                  fontSize: 30,
                  borderRadius: "48px",
                  boxShadow: "0 2px 16px #5eead433, 0 0.5px 2px #818cf866",
                  ml: 2,
                  border: "2.5px solid #67e8f9"
                }}
              >
                {cashBalance.toLocaleString()}円
              </Box>
            </Box>
            {/* ---- メモ欄 ---- */}
            <Box mb={2}>
              <Typography fontWeight={700} fontSize={16} color={accent} mb={0.5}>
                引き継ぎ事項・メモ
              </Typography>
              <TextField
                label="気づき/注意点/イレギュラーなど自由記入"
                variant="outlined"
                size="small"
                fullWidth
                multiline
                minRows={2}
                maxRows={5}
                value={memo}
                onChange={e => setMemo(e.target.value)}
                disabled={closed}
                sx={{ bgcolor: "#f7f8fa", borderRadius: 2 }}
              />
            </Box>
            {/* ---- アクション ---- */}
            <Stack direction="row" spacing={2} mt={2} justifyContent="flex-end">
              {!closed ? (
                <Button
                  variant="contained"
                  color="primary"
                  size="large"
                  sx={{
                    fontWeight: "bold", px: 4, borderRadius: 2, letterSpacing: 2, bgcolor: accent,
                    boxShadow: "0 2px 10px #6366f122",
                    "&:hover": { bgcolor: "#5856d6" }
                  }}
                  onClick={handleCloseButtonClick}
                  disabled={saving}
                >
                  {saving ? "保存中..." : "締め作業を完了する"}
                </Button>
              ) : (
                <Button
                  variant="text"
                  color="secondary"
                  sx={{ fontWeight: 700, borderRadius: 2 }}
                  onClick={handleUnlock}
                >
                  編集解除
                </Button>
              )}
            </Stack>
            {/* --- 追加: 写メ日記未取得時の確認ダイアログ --- */}
           <Dialog open={confirmNoDiaryOpen} onClose={() => setConfirmNoDiaryOpen(false)}>
             <DialogTitle>写メ日記未取得で締め作業を行いますか？</DialogTitle>
             <DialogContent>
               <Typography>
                 写メ日記が取得されていません。<br />
                 このまま締め作業を完了しますか？
               </Typography>
             </DialogContent>
             <DialogActions>
               <Button onClick={() => setConfirmNoDiaryOpen(false)}>キャンセル</Button>
               <Button
                 variant="contained"
                 color="primary"
                 onClick={() => {
                   setConfirmNoDiaryOpen(false);
                   handleClose();
                 }}
               >
                 はい、このまま完了する
               </Button>
             </DialogActions>
           </Dialog>
          </Box>
        </div>
      </GridLayout>
    </Box>
  );
}
