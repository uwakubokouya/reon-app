import React, { useState, useEffect } from "react";
import {
  Box, Paper, Typography, TextField, Button, InputAdornment,
  IconButton, FormControlLabel, Checkbox, Tabs, Tab
} from "@mui/material";
import KeyIcon from "@mui/icons-material/VpnKey";
import StoreIcon from "@mui/icons-material/Store";
import PersonIcon from "@mui/icons-material/Person";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { supabase } from "../lib/supabase";

// 管理者
const ADMIN_ID = "uwakubo";
const ADMIN_SECRET = "0906";
const STORE_LIST_KEY = "reon_admin_stores";

const accent = "#6366f1";
const cyan = "#06b6d4";
const gradBG = "linear-gradient(90deg, #e0e7ff 0%, #f1f5f9 80%)";

// 店舗データ取得
function getStoreList() {
  try { return JSON.parse(localStorage.getItem(STORE_LIST_KEY) || "[]"); } catch { return []; }
}

export default function LoginPage({ onLogin, onAdminLogin, onCastLogin }) {
  const [tab, setTab] = useState(0); // 0:店舗, 1:キャスト
  // 店舗
  const [storeId, setStoreId] = useState("");
  const [password, setPassword] = useState("");
  // キャスト
  const [castId, setCastId] = useState("");
  const [castPass, setCastPass] = useState("");
  // 共通
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState("");
  const [saveLogin, setSaveLogin] = useState(false);
  const [loading, setLoading] = useState(false);

  // 初期値セット
  useEffect(() => {
    const savedFlag = localStorage.getItem("reon_saveLogin") === "true";
    if (savedFlag) {
      setSaveLogin(true);
      setStoreId(localStorage.getItem("reon_storeId") || "");
      setPassword(localStorage.getItem("reon_password") || "");
      setCastId(localStorage.getItem("reon_castId") || "");
      setCastPass(localStorage.getItem("reon_castPass") || "");
    }
  }, []);

  // ログイン共通処理
  const handleLogin = async () => {
    setError(""); setLoading(true);

    // 管理者ログイン
    if (tab === 0 && storeId === ADMIN_ID && password === ADMIN_SECRET) {
      setLoading(false);
      if (saveLogin) {
        localStorage.setItem("reon_storeId", storeId);
        localStorage.setItem("reon_password", password);
        localStorage.setItem("reon_saveLogin", "true");
      } else {
        localStorage.removeItem("reon_storeId");
        localStorage.removeItem("reon_password");
        localStorage.setItem("reon_saveLogin", "false");
      }
      if (onAdminLogin) onAdminLogin();
      return;
    }

    // 店舗ログイン（localStorageから取得でOKな場合）
    if (tab === 0) {
      const stores = getStoreList();
      const found = stores.find(s => s.id === storeId && s.pass === password);
      setLoading(false);
      if (found) {
        if (saveLogin) {
          localStorage.setItem("reon_storeId", storeId);
          localStorage.setItem("reon_password", password);
          localStorage.setItem("reon_saveLogin", "true");
        } else {
          localStorage.removeItem("reon_storeId");
          localStorage.removeItem("reon_password");
          localStorage.setItem("reon_saveLogin", "false");
        }
        if (onLogin) onLogin(storeId, password, found);
      } else {
        setError("店舗IDまたはパスワードが違います");
      }
      return;
    }

    // キャストログイン（Supabaseで直接認証）
    if (tab === 1) {
      // 数値IDの時は数値化
      const castIdNum = String(Number(castId)); // "9"も"09"も"9"になる
      const { data, error: dbError } = await supabase
        .from("casts")
        .select("*")
        .eq("id", castIdNum)
        .eq("password", castPass)
        .maybeSingle();
      setLoading(false);
      if (data && data.id && String(data.id) === castIdNum && data.password === castPass) {
        if (saveLogin) {
          localStorage.setItem("reon_castId", castIdNum);
          localStorage.setItem("reon_castPass", castPass);
          localStorage.setItem("reon_saveLogin", "true");
        } else {
          localStorage.removeItem("reon_castId");
          localStorage.removeItem("reon_castPass");
          localStorage.setItem("reon_saveLogin", "false");
        }
        if (onCastLogin) onCastLogin(data.id, data.password, data);
      } else {
        setError("キャストIDまたはアイパスが違います");
      }
      return;
    }
  };

  // チェックボックス変更
  const handleCheckbox = (e) => {
    setSaveLogin(e.target.checked);
    if (!e.target.checked) {
      localStorage.removeItem("reon_storeId");
      localStorage.removeItem("reon_password");
      localStorage.removeItem("reon_castId");
      localStorage.removeItem("reon_castPass");
      localStorage.setItem("reon_saveLogin", "false");
    }
  };

  useEffect(() => {
    setError("");
    setShowPw(false);
  }, [tab]);

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: gradBG,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        p: 2,
      }}
    >
      <Paper
        sx={{
          width: 370,
          p: 4,
          borderRadius: 6,
          boxShadow: 7,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          background: "#fff",
        }}
      >
        <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 3, width: "100%" }}>
          <Tab icon={<StoreIcon />} label="店舗ログイン" />
          <Tab icon={<PersonIcon />} label="キャストログイン" />
        </Tabs>
        {tab === 0 ? (
          <>
            <Typography
              variant="h5"
              fontWeight={800}
              color={accent}
              mb={1}
              letterSpacing={1.5}
            >
              店舗ID・パスワードログイン
            </Typography>
            <Typography color="text.secondary" fontSize={15} mb={3}>
              店舗IDとパスワードを入力してください
            </Typography>
            <TextField
              label="店舗ID"
              value={storeId}
              onChange={(e) => setStoreId(e.target.value)}
              variant="outlined"
              fullWidth
              autoFocus
              sx={{ mb: 2, bgcolor: "#f8fafc" }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <StoreIcon sx={{ color: cyan }} />
                  </InputAdornment>
                ),
              }}
            />
            <TextField
              label="パスワード"
              type={showPw ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              variant="outlined"
              fullWidth
              sx={{ mb: 2, bgcolor: "#f8fafc" }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <KeyIcon sx={{ color: accent }} />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPw((s) => !s)}
                      edge="end"
                      size="small"
                      tabIndex={-1}
                    >
                      {showPw ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </>
        ) : (
          <>
            <Typography
              variant="h5"
              fontWeight={800}
              color={accent}
              mb={1}
              letterSpacing={1.5}
            >
              キャストID・アイパスログイン
            </Typography>
            <Typography color="text.secondary" fontSize={15} mb={3}>
              キャストIDとアイパスを入力してください
            </Typography>
            <TextField
              label="キャストID"
              value={castId}
              onChange={(e) => setCastId(e.target.value)}
              variant="outlined"
              fullWidth
              autoFocus
              sx={{ mb: 2, bgcolor: "#f8fafc" }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <PersonIcon sx={{ color: cyan }} />
                  </InputAdornment>
                ),
              }}
            />
            <TextField
              label="アイパス"
              type={showPw ? "text" : "password"}
              value={castPass}
              onChange={(e) => setCastPass(e.target.value)}
              variant="outlined"
              fullWidth
              sx={{ mb: 2, bgcolor: "#f8fafc" }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <KeyIcon sx={{ color: accent }} />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() => setShowPw((s) => !s)}
                      edge="end"
                      size="small"
                      tabIndex={-1}
                    >
                      {showPw ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </>
        )}

        <FormControlLabel
          control={
            <Checkbox
              checked={saveLogin}
              onChange={handleCheckbox}
              sx={{ color: cyan, "&.Mui-checked": { color: accent } }}
            />
          }
          label={
            <Typography fontSize={13} color="#64748b">
              次回からID・パスワードを自動入力する
            </Typography>
          }
          sx={{ alignSelf: "flex-start", mb: 1, ml: 0.5 }}
        />

        {error && (
          <Typography color="error" fontSize={14} mb={2} fontWeight={600}>
            {error}
          </Typography>
        )}

        <Button
          variant="contained"
          size="large"
          onClick={handleLogin}
          sx={{
            bgcolor: accent,
            color: "#fff",
            fontWeight: 900,
            fontSize: 18,
            mt: 1,
            px: 4,
            borderRadius: 3,
            "&:hover": { bgcolor: "#5856d6" },
            boxShadow: "0 2px 8px #6366f133",
          }}
          fullWidth
          disabled={loading}
        >
          {loading ? "認証中..." : "ログイン"}
        </Button>
      </Paper>
    </Box>
  );
}
