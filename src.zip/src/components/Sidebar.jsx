import React, { useMemo } from "react";
import {
  Dashboard, TableChart, Restaurant, Analytics, Chat, Settings, Delete,
} from "@mui/icons-material";
import { Button, Box, Typography, Select, MenuItem, IconButton } from "@mui/material";
import { useSettings } from "../SettingsContext";
import PersonAddAltIcon from "@mui/icons-material/PersonAddAlt";


// 管理画面で保存した全店舗情報（ID/パス/系列グループ...）を取得
function getAllAdminStores() {
  try {
    return JSON.parse(localStorage.getItem("reon_admin_stores") || "[]");
  } catch {
    return [];
  }
}

const menuList = [
  { key: "dashboard", label: "ダッシュボード", icon: <Dashboard /> },
  { key: "sales", label: "月間売上データ", icon: <TableChart /> },
  { key: "daily", label: "日報・締め", icon: <TableChart /> },
  { key: "tabelog", label: "スケジュール", icon: <Restaurant /> },
  { key: "customers", label: "顧客管理", icon: <PersonAddAltIcon /> },
  { key: "sns", label: "SNS分析", icon: <Analytics /> },
  { key: "advice", label: "AIアドバイス", icon: <Chat /> },
  { key: "settings", label: "設定", icon: <Settings /> },
];

export default function Sidebar({ page, setPage }) {
  const {
    currentStoreId,
    setCurrentStoreId,
    removeStore,
    storeDataMap
  } = useSettings();

  // 全店舗情報
  const allAdminStores = useMemo(getAllAdminStores, []);
  // 現在の店舗
  const currentAdminStore = allAdminStores.find(s => s.id === currentStoreId);
  const currentGroup = currentAdminStore ? currentAdminStore.group : null;

  // シリーズ（系列）店舗だけを抽出
  const shownStores = allAdminStores.filter(s =>
    currentGroup ? s.group === currentGroup : s.id === currentStoreId
  );

  // 店舗名
  const currentLabel = storeDataMap?.[currentStoreId]?.label || currentAdminStore?.label || "REON";

  // 1. 店舗切り替え時はlocalStorageも同期
  const handleChangeStore = (shopId) => {
    setCurrentStoreId(shopId);
    localStorage.setItem("reon_current_shopdir", shopId);
    // ※もしページ遷移したい場合はここでnavigate等
  };

  // 2. 初期化時にlocalStorageから選択
  React.useEffect(() => {
    if (!currentStoreId) {
      // 前回選択があれば
      const stored = localStorage.getItem("reon_current_shopdir");
      if (stored && allAdminStores.find(s => s.id === stored)) {
        setCurrentStoreId(stored);
      } else if (allAdminStores.length) {
        setCurrentStoreId(allAdminStores[0].id);
      }
    }
  }, [currentStoreId, allAdminStores, setCurrentStoreId]);

  // 3. 店舗削除時のcurrentStoreIdハンドリング
  const handleDeleteStore = () => {
    if (window.confirm(`本当に「${currentLabel}」を削除しますか？`)) {
      removeStore(currentStoreId);
      // 1件だけ消したら他を自動で選択
      const remaining = shownStores.filter(s => s.id !== currentStoreId);
      if (remaining.length) {
        handleChangeStore(remaining[0].id);
      } else {
        setCurrentStoreId(""); // 全部消えた場合
        localStorage.removeItem("reon_current_shopdir");
      }
    }
  };

  return (
    <Box sx={{
      width: 230,
      bgcolor: "#1e293b",
      color: "#fff",
      minHeight: "100vh",
      position: "fixed",
      left: 0,
      top: 0,
      zIndex: 1100,
      boxShadow: "2px 0 8px #0001",
      display: "flex",
      flexDirection: "column"
    }}>
      {/* --- 店舗セレクタ --- */}
      <Box sx={{ p: 2, pb: 1 }}>
        <Typography fontWeight={800} fontSize={15} color="#38bdf8" sx={{ mb: 0.5 }}>
          店舗選択
        </Typography>
        <Box display="flex" alignItems="center" gap={1}>
          <Select
            value={currentStoreId || ""}
            onChange={e => handleChangeStore(e.target.value)}
            size="small"
            fullWidth
            sx={{
              bgcolor: "#fff",
              color: "#222",
              borderRadius: 1,
              fontWeight: 700,
              fontSize: 15,
              mb: 0.5,
              '& .MuiSelect-select': { py: 1, px: 1.5 }
            }}
          >
            {shownStores.map(store => (
              <MenuItem value={store.id} key={store.id}>
                {store.label || store.id}
              </MenuItem>
            ))}
          </Select>
          {/* 削除ボタン（複数あるときだけ） */}
          {shownStores.length > 1 && currentStoreId &&
            <IconButton
              color="error"
              size="small"
              sx={{ ml: 0.5 }}
              onClick={handleDeleteStore}>
              <Delete fontSize="small" />
            </IconButton>
          }
        </Box>
      </Box>

      {/* --- メニュー --- */}
      <Box>
        {menuList.map((item) => (
          <Button
            key={item.key}
            variant={page === item.key ? "contained" : "text"}
            onClick={() => setPage(item.key)}
            startIcon={item.icon}
            sx={{
              color: "#fff",
              justifyContent: "flex-start",
              mb: 1,
              background: page === item.key ? "#334155" : "transparent",
              fontWeight: page === item.key ? "bold" : "normal",
              fontSize: "1.05rem",
              textTransform: "none",
              borderRadius: "0 20px 20px 0"
            }}
            fullWidth
          >
            {item.label}
          </Button>
        ))}
      </Box>
      <Box flex={1} />
      <Box sx={{ mb: 2, textAlign: "center", color: "#fff6" }}>
        <Typography fontSize={11}>© REON.AI</Typography>
      </Box>
    </Box>
  );
}
